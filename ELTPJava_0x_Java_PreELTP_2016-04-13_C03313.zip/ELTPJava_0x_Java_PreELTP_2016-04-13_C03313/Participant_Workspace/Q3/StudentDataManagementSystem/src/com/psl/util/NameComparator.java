package com.psl.util;

import java.util.Comparator;

import com.psl.beans.Student;

public class NameComparator implements Comparator<Student>{

	@Override
	public int compare(Student s0, Student s1) {
		String n1=s0.getStudentName();
		String n2=s1.getStudentName();
		if( n1.compareTo(n2) == 0)
		{
			AgeComparator a = new AgeComparator();
			return a.compare(s0, s1);
		}
		
		else
			return n1.compareTo(n2);
	}

}
