package com.psl.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.psl.beans.Address;
import com.psl.beans.Student;
import com.psl.exceptions.InsufficientDataException;

//Override all the methods of the DataManager Interface
public class StudentDataManager implements DataManager {

	List<Student> copy = new CopyOnWriteArrayList<Student>();
	
	@Override
	public List<Student> populateData(String fileName) {
		List<Student> student = new ArrayList<Student>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
		
			String line = null;
			
			int c=0;
			
			while((line = br.readLine())!=null)
			{
				
				if(line.compareTo(" ")!=0 && line.compareTo("")!=0)
				{
					
				String str[] = line.split(",");
				
				Address a = new Address(str[3],str[4],str[5]);
				
				if(str[0].compareTo("")==0 ) 
				{
					
					str[0]="0";
				}
				
				if(str[2].compareTo("")==0)
				{
					
					str[2]="0";
				}
				
				Student s = new Student(Integer.valueOf(str[0]),str[1],Integer.valueOf(str[2]),a);
				
				student.add(s);
				}
				
			}
		
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return student;
	}

	@Override
	public void validateData(List<Student> studentList)
			throws InsufficientDataException {
		
		int check=0;
		int i=0;
		
		
		copy = studentList;
			
		for(int j = 0; j<copy.size(); j++)
		{
			if((copy.get(j).getRollno()==0) || (copy.get(j).getStudentName().compareTo("")==0) || (copy.get(j).getAge()==0) || (copy.get(j).getAddress().getStreetName().compareTo("")==0) 
					|| (copy.get(j).getAddress().getCity().compareTo("")==0) || (copy.get(j).getAddress().getZipCode().compareTo("")==0))
			{
				check++;
				copy.remove(j);
			}
		}
		
		
		if(check!=0)
			throw new InsufficientDataException();
		
	}

	@Override
	public void sortData(List<Student> studentList) {
		
		copy.sort(new NameComparator());
		Iterator<Student> itr = copy.iterator();
		
		
	}

	
}
