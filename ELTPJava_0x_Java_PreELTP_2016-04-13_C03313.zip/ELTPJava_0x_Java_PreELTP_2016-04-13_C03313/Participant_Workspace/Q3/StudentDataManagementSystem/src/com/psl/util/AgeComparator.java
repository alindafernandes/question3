package com.psl.util;

import java.util.Comparator;

import com.psl.beans.Student;

public class AgeComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		Integer a1=o1.getAge();
		Integer a2=o2.getAge();
		
		
		if(a1.compareTo(a2)==0)
		{
			RollNoComparator r = new RollNoComparator();
			return r.compare(o1, o2);
		}
		else
			return a1.compareTo(a2);
		
	}

}
