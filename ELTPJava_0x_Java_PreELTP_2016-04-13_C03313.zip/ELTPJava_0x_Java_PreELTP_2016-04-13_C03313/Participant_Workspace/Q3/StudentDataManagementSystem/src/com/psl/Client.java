package com.psl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.psl.beans.Student;
import com.psl.exceptions.InsufficientDataException;
import com.psl.util.StudentDataManager;

public class Client {
	
	public static void main(String[] args) {
		
		//Create instance of StudentDataManager Class here and  test your functionality from here
	
		StudentDataManager dataManager = new StudentDataManager();
		
		List<Student> list = new ArrayList<Student>();
		
		
		//populate data from files into student list
		
		list = dataManager.populateData("StudentDetails.txt");
		
		
		//validating data
		
		try {
			dataManager.validateData(list);
			
			
		} catch (InsufficientDataException e) {
			
			e.printStackTrace();
		}
			
		//sorting data
		
		dataManager.sortData(list);
				
	}
}
