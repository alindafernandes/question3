package com.psl.util;

import java.util.Comparator;

import com.psl.beans.Student;

public class RollNoComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		Integer r1=o1.getRollno();
		Integer r2=o2.getRollno();
		
		return r1.compareTo(r2);
	}

}
