package com.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.exception.CityNotFoundException;
import com.exception.InvalidStateException;


// Override and implement the methods of Interface DataManager here 
public class DataManagerImpl implements DataManager {

	private static Map<String, List<String>> map = new HashMap<>();
	
	@Override
	public Map<String, List<String>> populateCityDataMap(String fileName)
			throws FileNotFoundException 
	{
		
		// List<String> list = new ArrayList<>();
		
		BufferedReader br=null;
		try {
			br = new BufferedReader(new FileReader(fileName));
			
			StringBuffer sb = new StringBuffer();
			
			String line=null;
			String msg=null;
						
				while((line=br.readLine())!=null)
				{
					sb.append(line).append(" ");
					msg = line;
					
					String words[] = msg.split("-");
					List<String> list = new ArrayList<>();
					if(map.containsKey(words[0]))
					{
						map.get(words[0]).add(words[1]);
					}
					else
					{
						list.add(words[1]);
						map.put(words[0],list);
					}
				}
				
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
			finally
			{
				try {
					br.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		return map;
	
	}
	@Override
	public List<String> getCities(Map<String, List<String>> stateCityMap,
			String state) throws InvalidStateException {
		
		int check = 0;
		
		for (Map.Entry<String,List<String>> entry : stateCityMap.entrySet())
		{
			if(entry.getKey().compareTo(state) == 0)
			{
				check ++;
				return entry.getValue();
			}
		}
		if(check==0)
			throw new InvalidStateException();
		return null;
	}

	@Override
	public String getState(Map<String, List<String>> stateCityMap, String city)
			throws CityNotFoundException {
		int check = 0;
		List<String> l = new ArrayList<>();
		for (Map.Entry<String,List<String>> entry : stateCityMap.entrySet())
		{
			l=entry.getValue();
			for (String c : l)
			{
				if(c.compareTo(city) == 0)
				{
					check ++;
					return entry.getKey();
				}
			}
		}
		if(check==0)
			throw new CityNotFoundException();
		return null;
	}

}
