package com.exception;

public class InvalidStateException extends Exception {
	public InvalidStateException() {
	}
}
