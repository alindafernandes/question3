package com.exception;

public class CityNotFoundException extends Exception {
	public CityNotFoundException() {
	}
}
