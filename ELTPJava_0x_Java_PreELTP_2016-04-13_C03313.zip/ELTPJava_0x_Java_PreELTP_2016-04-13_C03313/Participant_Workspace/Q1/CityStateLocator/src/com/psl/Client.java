package com.psl;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.exception.CityNotFoundException;
import com.exception.InvalidStateException;
import com.util.DataManagerImpl;


public class Client {
	
	public static void main(String[] args) {
		//Call your methods from here  to test the code implemented
		
		DataManagerImpl d = new DataManagerImpl();
		
		Map<String, List<String>> cityState = new HashMap<>();
		List<String> list = new ArrayList<>();
		String state;
		
		try {
			cityState = d.populateCityDataMap("StateCityDetails.txt");
			for(Map.Entry<String, List<String>> entry : cityState.entrySet())
			{	
				System.out.println(entry.getKey()+" "+entry.getValue());
			}
			
			list = d.getCities(cityState, "Goa");
			System.out.println("");
			System.out.println("Cities of Goa: ");
			
			Iterator itr = list.iterator();
			while(itr.hasNext())
				System.out.println(itr.next());
			
			//throws invalid state exception
			//list = d.getCities(cityState, "Karnataka");
			
			state = d.getState(cityState, "Ujjain");
			System.out.println("");
			System.out.println("State of city Ujjain :");
			
			System.out.println(state);
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} 
		catch (InvalidStateException e) {
			
			e.printStackTrace();
		} 
		catch (CityNotFoundException e) {
			
			e.printStackTrace();
		}
		
	}
}