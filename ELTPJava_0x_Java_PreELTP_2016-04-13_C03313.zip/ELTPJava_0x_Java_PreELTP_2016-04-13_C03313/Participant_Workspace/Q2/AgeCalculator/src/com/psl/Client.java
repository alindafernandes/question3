package com.psl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Client {

	
	public int findAge(String birthDate) throws InvalidDateFormatException {
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date d;
		
		try {
			if(!birthDate.matches("([0-9]{2})-([0-9]{2})-([0-9]{4})"))
				throw new InvalidDateFormatException();
			
			d = sdf.parse(birthDate);
			
			Date d1 = new Date();
			
			if(d.after(d1))
				return 0;
			
			else 
			{
				int age = d1.getYear() - d.getYear();
				return age;
			}
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
catch (InvalidDateFormatException e) {
			
			e.printStackTrace();
		}
		return 0;
	}

	public static void main(String[] args) {
		
		Client c = new Client();
		
		try {
			String date = "06-05-2017";
			int i = c.findAge(date);
			System.out.println(i);
		} 
catch (InvalidDateFormatException e) {
			
			e.printStackTrace();
		}
	}

}
