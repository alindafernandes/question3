package com.psl;

import java.util.ArrayList;
import java.util.List;

import com.psl.exception.NoDataFoundException;
import com.psl.util.PhoneBookContacts;
import com.psl.util.PhoneBookContactsImpl;

public class Client {
	
	public static void main(String[] args){
		
		//test your code by calling methods of the PhoneBookContacts from here
		
		PhoneBookContacts contacts=new PhoneBookContactsImpl();
		
		List <String>l1  = new ArrayList<>();
		l1.add("12345");
		l1.add("03215");
		
		contacts.addContact("abc", l1);
		
		List <String>l2  = new ArrayList<>();
		l2.add("75356");
		l2.add("95632");
		contacts.addContact("xyz",l2);
		
		List <String>l3  = new ArrayList<>();
		l3.add("75826");
		l3.add("97451");
		l3.add("18542");
		contacts.addContact("qwe",l3);
		
		System.out.println(contacts.getContactMap());
		
		
		try {
			System.out.println(contacts.searchContact("qwe"));
		} catch (NoDataFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
